# Project References Folder
Path:       ./references
Purpose:    The subfolders of this folder contain reference materials for AI agents to run against

## Subfolders
This section contains a subsection for each subfolder of this folder.

### ./_references/Wave-main
The original Wave theme for Ghost this project was cloned from repository at https://github.com/TryGhost/Wave
A live demo of this theme can be found at https://wave.ghost.io/


