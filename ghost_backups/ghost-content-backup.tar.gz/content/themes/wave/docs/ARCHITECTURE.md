# ARCHITECTURE.md

This document outlines the architecture of this project.

## System Architecture

